# N62 Telugu Voice Studio — Render Edition v1.4

This edition is designed for a Render **Web Service**.

## Features

- Single Telugu text → one MP3
- Bulk generation: up to 30 numbered texts
- Numbered filename matching
- Separate MP3 for each entry
- One ZIP download containing successful bulk files
- Neerja Indic (default), Shruti and Mohan
- Speed, pitch and volume controls
- Render health endpoint at `/health`

## GitHub structure

Upload these files/folders to the ROOT of your GitHub repository:

```text
public/
  index.html
server.mjs
package.json
render.yaml
README.md
```

## Render deployment

Create a **Web Service**, not a Static Site.

Recommended settings:

```text
Runtime: Node
Build Command: npm install
Start Command: npm start
```

Render must run the app on the `$PORT` environment variable. `server.mjs` already does this automatically.

After deployment:

```text
https://YOUR-SERVICE.onrender.com/
https://YOUR-SERVICE.onrender.com/health
https://YOUR-SERVICE.onrender.com/api/tts
```

The health URL should return JSON confirming version 1.4.0.

## Important

This project currently uses `msedge-tts`, which talks to Microsoft's Edge TTS service rather than the official paid Azure Speech SDK/API. If the upstream Edge service blocks a cloud-hosting IP or changes its protocol, TTS requests can fail even while the Render site itself is healthy. For a production deployment, the backend can be switched to the official Azure Speech API.
