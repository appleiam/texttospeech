import express from "express";
import { MsEdgeTTS, OUTPUT_FORMAT } from "msedge-tts";

const app = express();
const PORT = process.env.PORT || 10000;

app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false, limit: "100kb" }));

const VOICES = {
  neerja: { voice: "en-IN-NeerjaIndicNeural", label: "Neerja Indic" },
  shruti: { voice: "te-IN-ShrutiNeural", label: "Shruti" },
  mohan: { voice: "te-IN-MohanNeural", label: "Mohan" },
  "en-IN-NeerjaIndicNeural": { voice: "en-IN-NeerjaIndicNeural", label: "Neerja Indic" },
  "te-IN-ShrutiNeural": { voice: "te-IN-ShrutiNeural", label: "Shruti" },
  "te-IN-MohanNeural": { voice: "te-IN-MohanNeural", label: "Mohan" }
};

function clamp(value, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.max(min, Math.min(max, Math.round(n)));
}

function safeFilename(value) {
  let name = String(value || "telugu_voice.mp3").trim();
  name = name.replace(/[\\/:*?"<>|\x00-\x1F]/g, "_");
  if (!name.toLowerCase().endsWith(".mp3")) name += ".mp3";
  return name.slice(0, 180);
}

function streamToBuffer(stream, timeoutMs = 35000) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let settled = false;

    const cleanup = () => clearTimeout(timer);

    const finish = () => {
      if (settled) return;
      settled = true;
      cleanup();
      const audio = Buffer.concat(chunks);
      if (!audio.length) reject(new Error("No audio data was returned by the TTS service."));
      else resolve(audio);
    };

    const fail = (error) => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(error instanceof Error ? error : new Error(String(error)));
    };

    const timer = setTimeout(() => fail(new Error("TTS generation timed out.")), timeoutMs);
    stream.on("data", chunk => chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)));
    stream.on("end", finish);
    stream.on("close", finish);
    stream.on("error", fail);
  });
}

async function synthesize(text, voiceName, rate, pitch, volume) {
  const tts = new MsEdgeTTS();

  try {
    await tts.setMetadata(
      voiceName,
      OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3
    );

    const { audioStream } = await tts.toStream(text, {
      rate: `${rate >= 0 ? "+" : ""}${rate}%`,
      pitch: `${pitch >= 0 ? "+" : ""}${pitch}Hz`,
      volume: `${volume >= 0 ? "+" : ""}${volume}%`
    });

    return await streamToBuffer(audioStream);
  } finally {
    try { tts.close(); } catch {}
  }
}

app.get("/health", (_req, res) => {
  res.json({
    ok: true,
    version: "1.4.0",
    platform: "Render",
    engine: "msedge-tts",
    defaultVoice: "en-IN-NeerjaIndicNeural"
  });
});

app.get("/api/tts", (_req, res) => {
  res.json({
    ok: true,
    version: "1.4.0",
    engine: "msedge-tts",
    defaultVoice: "en-IN-NeerjaIndicNeural",
    detail: "TTS API is running."
  });
});

app.post("/api/tts", async (req, res) => {
  const data = req.body || {};
  const text = String(data.text || "").trim();

  if (!text) {
    return res.status(400).json({ detail: "Please enter Telugu text." });
  }

  if (text.length > 2500) {
    return res.status(400).json({ detail: "Maximum 2500 characters per request." });
  }

  const selected = VOICES[data.voice] || VOICES.neerja;
  const filename = safeFilename(data.filename);
  const rate = clamp(data.rate, -40, 40);
  const pitch = clamp(data.pitch, -30, 30);
  const volume = clamp(data.volume, -40, 40);

  try {
    const audio = await synthesize(text, selected.voice, rate, pitch, volume);

    res.status(200);
    res.set({
      "Content-Type": "audio/mpeg",
      "Content-Length": String(audio.length),
      "Content-Disposition": `attachment; filename="${filename.replace(/"/g, "")}"; filename*=UTF-8''${encodeURIComponent(filename)}`,
      "Cache-Control": "no-store",
      "X-TTS-Voice": selected.voice,
      "X-TTS-Engine": "msedge-tts"
    });

    return res.end(audio);
  } catch (error) {
    console.error("TTS generation failed:", error);
    const message = error instanceof Error ? error.message : String(error);

    return res.status(502).json({
      detail: "Speech generation failed on the server.",
      error: message,
      voice: selected.voice,
      version: "1.4.0"
    });
  }
});

app.use(express.static("public", {
  extensions: ["html"],
  maxAge: 0
}));

app.get("*", (_req, res) => {
  res.sendFile("index.html", { root: "public" });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`N62 Telugu Voice Studio running on 0.0.0.0:${PORT}`);
});
